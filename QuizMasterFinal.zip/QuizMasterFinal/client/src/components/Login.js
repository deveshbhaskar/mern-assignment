import React, { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col, Form, Button, Alert } from 'react-bootstrap'; 
import { UserContext } from '../context/UserContext';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [error, setError] = useState('');
  const { login, user } = useContext(UserContext);
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const response = await fetch('http://localhost:5000/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    const data = await response.json();
    console.log(data);

    if (response.ok) {
      console.log(data.user);
      login(data.token, data.user);
      navigate('/dashboard');
    } else {
      setError(data.msg || 'Login failed. Please check your credentials.');
    }
  };

  const handleSignupRedirect = () => {
    navigate('/signup');
  };

  return (
    <>
      <h1 className="display-6 text-center fw-bold m-5">Welcome to QuizMaster</h1>
      <Container className="d-flex justify-content-center align-items-center" style={{ height: '60vh' }}>
        <Row className="w-100 justify-content-center">
          <Col sm={12} md={6} lg={4}>
            <div className="card shadow-sm p-4 rounded">
              <div className="text-center mb-4">
                <p className="text-muted">Sharpen Your Skills Today!</p>
                <p className="text-secondary small">
                  An engaging online quiz platform for students in grades 7-10.
                </p>
              </div>

              {error && <Alert variant="danger">{error}</Alert>}
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3" controlId="formEmail">
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    type="email"
                    name="email"
                    placeholder="Enter your email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3" controlId="formPassword">
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    name="password"
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={handleChange}
                    required
                  />
                </Form.Group>

                <Button variant="primary" type="submit" className="w-100 mb-3">Login</Button>
              </Form>
              
              <div className="text-center">
                <p className="mb-2">Don't have an account?</p>
                <Button variant="outline-primary" className="w-100" onClick={handleSignupRedirect}>
                  Sign Up
                </Button>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default Login;
