import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const Result = () => {
  const navigate = useNavigate();
  const [score, setScore] = useState(0);
  const [totalQuestions, setTotalQuestions] = useState(0);

  useEffect(() => {
    const userScore = localStorage.getItem('quizScore');
    const total = localStorage.getItem('totalQuestions');
    
    if (userScore && total) {
      setScore(Number(userScore));
      setTotalQuestions(Number(total));
    }
  }, []);

  const handleGoBack = () => {
    localStorage.removeItem('quizScore');
    localStorage.removeItem('totalQuestions');
    navigate('/dashboard');
  };

  const percentage = ((score / totalQuestions) * 100).toFixed(2);

  const getFeedback = () => {
    if (percentage >= 80) {
      return "Excellent work!";
    } else if (percentage >= 50) {
      return "Good job, but there's room for improvement.";
    } else {
      return "You need more practice, keep trying!";
    }
  };

  return (
    <Container>
      <Row>
        <Col>
          <Card className="mt-5 p-4">
            <Card.Body>
              <Card.Title>Quiz Results</Card.Title>
              <Card.Text>Your score: {score} / {totalQuestions}</Card.Text>
              <Card.Text>Percentage: {percentage}%</Card.Text>
              <Card.Text>{getFeedback()}</Card.Text>
              <Button onClick={handleGoBack} variant="primary">
                Back to Dashboard
              </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Result;
