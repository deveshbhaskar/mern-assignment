import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import { UserProvider } from './context/UserContext';
import ApiTest from './ApiTest';
import Signup from './components/Signup';
import Login from './components/Login';
// import Dashboard from './components/Dashboard'; 
import 'bootstrap/dist/css/bootstrap.min.css';
import Dashboard from './pages/Dashboard';
import Quiz from './pages/Quiz';
import Result from './components/Result';

function App() {
  return (
    <UserProvider>
      <Router>
        <Routes>
          <Route path="/signup" element={<Signup />} />
          <Route path="/" element={<Login />} />
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/quiz" element={<Quiz />} />
          <Route path="/quiz/result" element={<Result />} />
        </Routes>
      </Router>
    </UserProvider>
  );
}

export default App;
