import React, { useState, useEffect, useContext } from 'react';
import { Container, Row, Col, Card, Button, Dropdown, Modal, Form, Alert } from 'react-bootstrap';
import { UserContext } from '../context/UserContext';
import { useNavigate } from 'react-router-dom';
import { FaUserCircle } from 'react-icons/fa';

const Dashboard = () => {
  const { user, setUser, logout } = useContext(UserContext);
  const navigate = useNavigate();

  const [previousScore, setPreviousScore] = useState(null);
  const [totalQuestions, setTotalQuestions] = useState(null);
  const [showChangeNameModal, setShowChangeNameModal] = useState(false); 
  const [showChangePasswordModal, setShowChangePasswordModal] = useState(false); 
  const [newName, setNewName] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [oldPassword, setOldPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const score = localStorage.getItem('quizScore');
    const total = localStorage.getItem('totalQuestions');

    if (score && total) {
      setPreviousScore(score);
      setTotalQuestions(total);
    }

    if (user) {
      window.history.pushState(null, '', window.location.href);
      window.onpopstate = () => {
        window.history.pushState(null, '', window.location.href);
      };
    }

    return () => {
      window.onpopstate = null;
    };
  }, [user]);

  const handleStartQuiz = () => {
    localStorage.removeItem('quizScore');
    localStorage.removeItem('totalQuestions');
    navigate('/quiz');
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleChangeName = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/api/auth/change-name', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`, // Send token for authentication
        },
        body: JSON.stringify({ newName }),
      });

      const data = await response.json();
      if (response.ok) {
        setSuccess('Name changed successfully!');
        setTimeout(() => {
          const updatedUser = { ...user, userName: newName };
          setUser(updatedUser);

          localStorage.setItem('user', JSON.stringify(updatedUser));

          setShowChangeNameModal(false);
          setNewName('');
          window.location.reload();
        }, 500);
      } else {
        setError(data.msg || 'Error updating name.');
      }
    } catch (err) {
      setError('Server error, please try again later.');
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setError('New password and confirm password do not match.');
      return;
    }

    try {
      const response = await fetch('http://localhost:5000/api/auth/change-password', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`, // Send token for authentication
        },
        body: JSON.stringify({ oldPassword, newPassword }),
      });

      const data = await response.json();
      if (response.ok) {
        setSuccess('Password changed successfully!');
        setTimeout(() => {
          setShowChangePasswordModal(false);
          setOldPassword('');
          setNewPassword('');
          setConfirmPassword('');
        }, 2000);
      } else {
        setError(data.msg || 'Error updating password.');
      }
    } catch (err) {
      setError('Server error, please try again later.');
    }
  };

  return (
    <>
      <section style={{ backgroundColor: '#f5f5f5', padding: '20px 0' }}>
      <h1 className="display-6 text-center fw-bold m-5">Welcome to QuizMaster</h1>
        <Container className="d-flex justify-content-center align-items-center" style={{ minHeight: '60vh' }}>
          <Row className="w-100 justify-content-center">
            <Col sm={12} md={8} lg={6}>
              <Card className="shadow-sm p-4" style={{ backgroundColor: '#ffffff' }}>
                <Card.Body>
                  <div className='d-flex justify-content-between'>
                    <Card.Title style={{ fontFamily: 'Arial, sans-serif', fontSize: '28px', fontWeight: 'bold' }}>Welcome to the Dashboard!</Card.Title>
                    {user && <Dropdown align="end">
                      <Dropdown.Toggle variant="success" id="dropdown-basic" className="dropdown-toggle-custom">
                        <FaUserCircle size={30} />
                      </Dropdown.Toggle>
                      <Dropdown.Menu className="dropdown-menu-custom">
                        <Dropdown.Item onClick={() => setShowChangeNameModal(true)}>Change Name</Dropdown.Item>
                        <Dropdown.Item onClick={handleLogout}>Logout</Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>}
                  </div>

                  {user ? (
                    <>
                      <p style={{ fontSize: '18px', fontWeight: 'bold' }}>Hello, {user.userName}</p>
                      <p>Your email: {user.email}</p>

                      {previousScore && totalQuestions ? (
                        <p>
                          Previous Result: {previousScore} / {totalQuestions} ({((previousScore / totalQuestions) * 100).toFixed(2)}%)
                        </p>
                      ) : (
                        <p>No previous quiz results found.</p>
                      )}

                      <div className="d-flex justify-content-between align-items-center">
                        <Button variant="primary" onClick={handleStartQuiz}>Start Quiz</Button>
                      </div>
                    </>
                  ) : (
                    <>
                      <p>You are not logged in.</p>
                      <Button variant="primary" onClick={() => navigate('/login')} className="mt-3">
                        Log In
                      </Button>
                    </>
                  )}
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </section>

      <Modal show={showChangeNameModal} onHide={() => setShowChangeNameModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Change Your Name</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {error && <Alert variant="danger">{error}</Alert>}
          {success && <Alert variant="success">{success}</Alert>}
          <Form onSubmit={handleChangeName}>
            <Form.Group controlId="formNewName">
              <Form.Label>New Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter your new name"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                required
              />
            </Form.Group>
            <div className="d-flex justify-content-end mt-3">
              <Button variant="secondary" onClick={() => setShowChangeNameModal(false)} className="me-2">
                Cancel
              </Button>
              <Button variant="primary" type="submit">
                Save Changes
              </Button>
            </div>
          </Form>
        </Modal.Body>
      </Modal>

      {/* <Modal show={showChangePasswordModal} onHide={() => setShowChangePasswordModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Change Your Password</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {error && <Alert variant="danger">{error}</Alert>}
          {success && <Alert variant="success">{success}</Alert>}
          <Form onSubmit={handleChangePassword}>
            <Form.Group controlId="formOldPassword">
              <Form.Label>Old Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Enter your old password"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                required
              />
            </Form.Group>
            <Form.Group controlId="formNewPassword" className="mt-3">
              <Form.Label>New Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Enter your new password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
              />
            </Form.Group>
            <Form.Group controlId="formConfirmPassword" className="mt-3">
              <Form.Label>Confirm New Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Confirm your new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </Form.Group>
            <div className="d-flex justify-content-end mt-3">
              <Button variant="secondary" onClick={() => setShowChangePasswordModal(false)} className="me-2">
                Cancel
              </Button>
              <Button variant="primary" type="submit">
                Save Changes
              </Button>
            </div>
          </Form>
        </Modal.Body>
      </Modal> */}
    </>
  );
};

export default Dashboard;
