import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, ProgressBar } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const Quiz = () => {
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [score, setScore] = useState(0);
  const [answeredQuestions, setAnsweredQuestions] = useState(0);
  const [loading, setLoading] = useState(true);
  const [answersHistory, setAnswersHistory] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/quiz/questions');
        const data = await response.json();
        setQuestions(data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching questions:', error);
        setLoading(false);
      }
    };

    fetchQuestions();
  }, []);

  if (loading) {
    return <Container><Row><Col><h3>Loading questions...</h3></Col></Row></Container>;
  }

  const question = questions[currentQuestionIndex];

  const handleAnswer = (answer) => {
    setSelectedAnswer(answer);
  };

  const submitAnswer = () => {
    if (selectedAnswer === question.correctAnswer) {
      setScore(score + 1);
    }
    setAnsweredQuestions(answeredQuestions + 1);

    const updatedAnswersHistory = [...answersHistory];
    updatedAnswersHistory[currentQuestionIndex] = selectedAnswer;
    setAnswersHistory(updatedAnswersHistory);

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null); 
    } else {
      localStorage.setItem('quizScore', score + 1);
      localStorage.setItem('totalQuestions', questions.length);

      navigate('/quiz/result');
    }
  };

  const quitQuiz = () => {
    localStorage.setItem('quizScore', score);
    localStorage.setItem('totalQuestions', questions.length);
    
    navigate('/dashboard');
  };

  const goBackToPreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
      setSelectedAnswer(answersHistory[currentQuestionIndex - 1] || null);
    }
  };

  return (<>
    <Container>
      <Row>
        <Col>
          <Card className="mt-5 p-4">
            <Card.Body>
              <Card.Title>Question {currentQuestionIndex + 1}</Card.Title>
              <Card.Text>{question.question}</Card.Text>

              <div>
                {question.options.map((option, index) => (
                  <Button
                    key={index}
                    variant={selectedAnswer === option ? "primary" : "outline-primary"}
                    onClick={() => handleAnswer(option)}
                    className={`m-2 ${selectedAnswer === option ? 'selected' : ''}`}
                  >
                    {option}
                  </Button>
                ))}
              </div>

              <Button
                variant="success"
                onClick={submitAnswer}
                className="mt-3"
                disabled={!selectedAnswer}
              >
                Submit Answer
              </Button>

              {currentQuestionIndex > 0 && (
                <Button
                  variant="secondary"
                  onClick={goBackToPreviousQuestion}
                  className="mt-3 ms-2"
                >
                  Go Back
                </Button>
              )}

              <Button
                variant="danger"
                onClick={quitQuiz}
                className="mt-3 ms-2"
              >
                Quit Quiz
              </Button>

              <ProgressBar
                now={(answeredQuestions / questions.length) * 100}
                label={`Progress: ${answeredQuestions}/${questions.length}`}
                className="mt-3"
              />
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
    </>
  );
};

export default Quiz;
