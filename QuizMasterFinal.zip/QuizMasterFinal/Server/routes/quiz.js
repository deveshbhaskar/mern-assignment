const express = require('express');
const Quiz = require('../models/Quiz');
const router = express.Router();

// Fetch all quiz questions
router.get('/questions', async (req, res) => {
  try {
    const questions = await Quiz.find();
    res.status(200).json(questions);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});


router.post('/insertQuestions', async (req, res) => {
    const { question, options, correctAnswer, difficulty, topic } = req.body;
  
    // Check if all required fields are provided
    if (!question || !options || !correctAnswer || !difficulty || !topic) {
      return res.status(400).json({ error: 'All fields are required.' });
    }
  
    try {
      // Create a new quiz question document
      const newQuizQuestion = new Quiz({
        question,
        options,
        correctAnswer,
        difficulty,
        topic,
      });
  
      // Save the quiz question to the database
      await newQuizQuestion.save();
  
      // Respond with success message
      res.status(201).json({ message: 'Quiz question added successfully', newQuizQuestion });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Server error' });
    }
  });
module.exports = router;
