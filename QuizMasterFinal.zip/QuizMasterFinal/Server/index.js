// Import required modules
const express = require('express'); // Web framework
const mongoose = require('mongoose'); // MongoDB library
const dotenv = require('dotenv'); // For environment variables
const quizRoutes = require('./routes/quiz');

// Initialize Express
const app = express();

// Middleware to parse JSON requests
app.use(express.json());

// Load environment variables from .env file
dotenv.config();

// Define a simple route for testing
app.get('/', (req, res) => {
  res.send('Server is running successfully!');
});

app.get('/api/test', (req, res) => {
  res.json({ message: 'API is working!' });
});

const authRoutes = require('./routes/auth');

app.use('/api/auth', authRoutes);

app.use('/api/quiz', quizRoutes);

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));


// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

